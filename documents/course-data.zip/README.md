# Data Sets

## sPlotOpen

Consider including [this data](https://idata.idiv.de/ddm/Data/ShowData/3474?version=76) in the course.
